import { TestBed } from '@angular/core/testing';

import { Enums } from './enums';

describe('Enums', () => {
  /*let service: DbService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DbService);
  });
*/
  it('should be created', () => {
    expect(new Enums()).toBeTruthy();
  });
});


